/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.edu.utng.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import mx.edu.utng.model.Almacen;
import mx.edu.utng.util.UtilDB;

/**
 *
 * @author Ricardo Hernandez Centeno
 */
public class AlmacenDAOImp implements AlmacenDAO {

    private Connection connection;

    public AlmacenDAOImp() {
        connection = UtilDB.getConnection();
    }

    @Override
    public void agregarAlmacen(Almacen almacen) {
        
        try {
            String query = "INSERT INTO almacenes(nombre, direccion,telefono,pais) VALUES(?, ?, ?, ?)";
            PreparedStatement ps = connection.prepareCall(query);
            ps.setString(1, almacen.getNombre());
            ps.setString(2, almacen.getDireccion());
            ps.setInt(3, almacen.getTelefono());
            ps.setString(4, almacen.getPais());
            ps.executeUpdate();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void borrarAlmacen(int idAlmacen) {
        
        try {
            String query = "DELETE FROM almacenes WHERE id_almacen=?";
            PreparedStatement ps = connection.prepareCall(query);
            ps.setInt(1, idAlmacen);
            ps.executeUpdate();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void cambiarAlmacen(Almacen almacen) {
        
        try {
            String query = "UPDATE almacenes SET  nombre=?, direccion=?,telefono=?,pais=?  WHERE id_almacen=?";
            PreparedStatement ps = connection.prepareCall(query);
            ps.setString(1, almacen.getNombre());
            ps.setString(2, almacen.getDireccion());
            ps.setInt(3, almacen.getTelefono());
            ps.setString(4, almacen.getPais());
            ps.setInt(5, almacen.getIdAlmacen());
            ps.executeUpdate();
            ps.close();
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Almacen> desplegarAlmacenes() {
        List<Almacen> almacenes = new ArrayList<Almacen>();
        try {
            Statement s = connection.createStatement();
            ResultSet rs = s.executeQuery("SELECT * FROM almacenes");
            while (rs.next()) {
                Almacen almacen = new Almacen(
                        rs.getInt("id_almacen"),
                        rs.getString("nombre"),
                        rs.getString("direccion"),
                        rs.getInt("telefono"),
                        rs.getString("pais"));
                almacenes.add(almacen);
            }
            rs.close();
            s.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return almacenes;
    }

    @Override
    public Almacen elegirAlmacen(int idAlmacen) {
        Almacen almacen = new Almacen();
        try {
            PreparedStatement ps = connection.prepareStatement("SELECT * FROM almacenes WHERE id_almacen=?");
            ps.setInt(1, idAlmacen);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                almacen.setIdAlmacen(rs.getInt("id_almacen"));
                almacen.setNombre(rs.getString("nombre"));
                almacen.setDireccion(rs.getString("direccion"));
                almacen.setTelefono(rs.getInt("telefono"));
                almacen.setPais(rs.getString("pais"));
               
            }
            rs.close();
            ps.close();
        }catch (SQLException e){
            e.printStackTrace();
        }
        return almacen;
    }
}
